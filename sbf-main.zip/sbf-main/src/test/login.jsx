import React from "react";
import { Formik, Form, Field } from "formik";
import { Link } from "react-router-dom";

const LoginPage = () => {
  return (
    <div className="h-[100vh] flex justify-center items-center">
      <div className="h-auto bg-gray-500 pt-2 pb-4 px-20 rounded w-[40%]">
        <Formik
          initialValues={{
            email: "",
            password: "",
          }}
          onSubmit={(values) => {
            console.log(values);
          }}
        >
          <Form className="flex flex-col gap-2">
            <div className="flex flex-col">
              <p className="text-[15px] text-white">Login here!</p>
              <p className="text-[12px] text-white">
                Don't have an account?{" "}
                <Link className="text-blue-400 underline" to="/register">
                  click here
                </Link>
              </p>
            </div>
            <div className="flex flex-col gap-5 mt-2">
              <Field
                className="rounded px-2 py-3 h-6 text-[12px] outline-none"
                name="email"
                type="email"
                placeholder="Email"
              />
              <Field
                className="rounded px-2 py-3 h-6 text-[12px] outline-none"
                name="password"
                type="password"
                placeholder="Confirm Password"
              />
            </div>
            <div className="text-[12px] flex gap-2">
              <p className="text-white">Forgot password?</p>
              <p className="text-white">
                <a className="text-blue-400 underline" href="#">
                  Click here
                </a>{" "}
                to reset.
              </p>
            </div>
            <button
              type="submit"
              className="bg-bodyTheme font-semibold rounded text-[15px] text-white py-1"
            >
              Login
            </button>
          </Form>
        </Formik>
      </div>
    </div>
  );
};

export default LoginPage;
