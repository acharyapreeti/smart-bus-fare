import React , {useState} from 'react'
import {CiSaveUp2} from 'react-icons/ci'
import {RxCross2} from 'react-icons/rx'
import {TiTickOutline} from 'react-icons/ti'
import {RxUpdate} from 'react-icons/rx'

const AdminViewInfo = () => {

  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileChange = (event) => {
    setSelectedFile(event.target.files[0]);
  };

    const [selectedOption, setSelectedOption] = useState('');
    const [selectedOption2, setSelectedOption2] = useState('');

    const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
    };
    const handleOptionChange2 = (event) => {
    setSelectedOption2(event.target.value);
    };

  return (
    <div className='h-[100vh] w-full bg-bodyTheme flex flex-col items-center justify-center gap-4'>
            <div className='h-auto w-[70%] bg-gray-500 border-2 rounded-md  cursor-pointer px-[3rem] flex items-center justify-center  gap-2'>
                    <div className='w-[50%] gap-5 flex flex-col pl-[5rem] '>
                        <div>
                            <h2 className='px-[10px] text-[25px]  font-semibold text-white'>Personal Details</h2>
                        </div>
                        <div className='flex flex-col gap-2'>
                            <input
                                   type="text"
                                   placeholder='Name'
                                   className="rounded px-2 w-[12rem] py-3 h-8 text-[12px] outline-none"
                            />
                            <input
                                   type="email"
                                   placeholder='Email'
                                   className="rounded px-2 w-[12rem] py-3 h-8 text-[12px] outline-none"
                            />
                            <input
                                   type="text"
                                   placeholder='Address'
                                   className="rounded px-2 w-[12rem] py-3 h-8 text-[12px] outline-none"
                            />
                            <input
                                   type="number"
                                   placeholder='Date of Birth'
                                   className="rounded px-2 w-[12rem] py-3 h-8 text-[12px] outline-none"
                            />
                            <input
                                   type="number"
                                   placeholder='Gender'
                                   className="rounded px-2 w-[12rem] py-3 h-8 text-[12px] outline-none"
                            />
                            <input
                                   type="number"
                                   placeholder='Phone Number'
                                   className="rounded px-2 w-[12rem] py-3 h-8 text-[12px] outline-none"
                            />
                        </div>
                    </div>
                    <div className='w-[50%] flex flex-col gap-3 border-l-[1px] justify-center items-center pl-10 py-5'>
                        <div>
                            <h2 className='px-[10px] text-[25px]  font-semibold text-white'>Document Details</h2>
                        </div>
                        <div className='flex flex-col gap-2 mb-2 text-white border-[1px] rounded-md border-white px-5 py-2'>
                            <h2 className='h-[80px] w-[150px] flex justify-center items-center'>Profile Picture Here</h2>
                        </div>
                        <div className='flex flex-col gap-2 text-white border-[1px] rounded-md border-white px-5 py-2'>
                            <h2 className='h-[80px] w-[150px] flex justify-center items-center'>Identity Proof Document:</h2>
                            
                        </div>
                        <div className='flex gap-3'>
                        <button className=' text-center px-[1rem] border-green-500 rounded-md text-white border-2 flex justify-center items-center gap-3 bg-green-500'>
                                <div>
                                   Accept
                                </div>
                                <TiTickOutline/>
                             </button>
                             <button className=' text-center px-[1rem] border-red-500 rounded-md text-white border-2 flex justify-center items-center gap-3 bg-red-500'>
                                <div>
                                   Reject
                                </div>
                                <RxCross2/>
                             </button>
                            <button className=' text-center px-[1rem] border-bodyTheme rounded-md text-white border-2 flex justify-center items-center gap-3 bg-bodyTheme'>
                                <div>
                                   Update
                                </div>
                                <RxUpdate color='white'/>
                             </button>
                             
                             
                        </div>
                    </div>
                    
                    
            </div>
    </div>
  )
}

export default AdminViewInfo;


