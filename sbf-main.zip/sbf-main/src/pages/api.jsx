import React from 'react';
import { useLocation } from 'react-router-dom';

const DisplayPage = () => {
  const location = useLocation();
  const formData = location.state;

  return (
    <div className='h-[100vh] w-full bg-bodyTheme flex flex-col items-center justify-center'>
      <h1 className='text-2xl font-semibold text-white mb-4'>Display Page</h1>

      {formData && (
        <div className='bg-gray-500 border-2 rounded-md p-4'>
          <h2 className='text-lg font-semibold text-white mb-2'>Personal Details:</h2>
          <p className='text-white'>Name: {formData.name}</p>
          <p className='text-white'>Email: {formData.email}</p>
          {/* Add more fields for other personal details */}

          {/* <h2 className='text-lg font-semibold text-white mt-4 mb-2'>Document Details:</h2>
          <p className='text-white'>Profile Picture: {formData.profilePicture && formData.profilePicture.name}</p>
          <p className='text-white'>Document Proof: {formData.documentProof && formData.documentProof.name}</p> */}
        </div>
      )}
    </div>
  );
};

export default DisplayPage;



