






























// import React, { useState } from 'react';
// import axios from 'axios';

// const RegisterPage = () => {
//   const [formData, setFormData] = useState({
//     name: '',
//     email: '',
//     address: '',
//     phoneNumber: '',
//     password: '',
//     confirmPassword: '',
//     userType: '',
//     gender: '',
//     agreeTerms: false,
//   });

//   const [registrationStatus, setRegistrationStatus] = useState('');

//   const handleInputChange = (e) => {
//     const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
//     setFormData({
//       ...formData,
//       [e.target.name]: value,
//     });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     try {
//       const response = await axios.post('http://localhost:3031/users', formData);
//       if (response.status === 204) {
//         setRegistrationStatus('Registration successful!');
//         // Reset form fields
//         setFormData({
//           name: '',
//           email: '',
//           address: '',
//           phoneNumber: '',
//           password: '',
//           confirmPassword: '',
//           userType: '',
//           gender: '',
//           agreeTerms: false,
//         });
//       }
//     } catch (error) {
//       console.error('Error:', error);
//     }
//   };

//   return (
//     <div>
//       {registrationStatus && <p>{registrationStatus}</p>}
//       <form onSubmit={handleSubmit}>
//       <label htmlFor="name">Name:</label>
//       <input type="text" id="name" name="name" value={formData.name} onChange={handleInputChange} />

//       <label htmlFor="email">Email:</label>
//       <input type="email" id="email" name="email" value={formData.email} onChange={handleInputChange} />

//       <label htmlFor="address">Address:</label>
//       <input type="text" id="address" name="address" value={formData.address} onChange={handleInputChange} />

//       <label htmlFor="phoneNumber">Phone Number:</label>
//       <input type="tel" id="phoneNumber" name="phoneNumber" value={formData.phoneNumber} onChange={handleInputChange} />

//       <label htmlFor="password">Password:</label>
//       <input type="password" id="password" name="password" value={formData.password} onChange={handleInputChange} />

//       <label htmlFor="confirmPassword">Confirm Password:</label>
//       <input type="password" id="confirmPassword" name="confirmPassword" value={formData.confirmPassword} onChange={handleInputChange} />

//       <label htmlFor="userType">User Type:</label>
//       <select id="userType" name="userType" value={formData.userType} onChange={handleInputChange}>
//         <option value="">Select User Type</option>
//         <option value="bmc">BMC</option>
//         <option value="staff">Staff</option>
//         <option value="commuter">Commuter</option>
//       </select>

//       <label htmlFor="gender">Gender:</label>
//       <select id="gender" name="gender" value={formData.gender} onChange={handleInputChange}>
//         <option value="">Select Gender</option>
//         <option value="male">Male</option>
//         <option value="female">Female</option>
//         <option value="other">Other</option>
//       </select>

//       <label htmlFor="agreeTerms">
//         <input type="checkbox" id="agreeTerms" name="agreeTerms" checked={formData.agreeTerms} onChange={handleInputChange} />
//         By registering, you agree to the terms & conditions
//       </label>

//       <button type="submit">Register</button>
//       </form>
//     </div>
//   );
// };

// export default RegisterPage;
