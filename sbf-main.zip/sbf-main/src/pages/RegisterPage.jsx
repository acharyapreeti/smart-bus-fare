import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

const RegisterPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    phoneNumber: '',
    password: '',
    confirmPassword: '',
    userType: '',
    gender: '',
    agreeTerms: false
  });
  const [successMessage, setSuccessMessage] = useState('');

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Add your API endpoint URL
    const apiUrl = 'http://localhost:3031/users';

    // Perform the API request
    axios.post(apiUrl, formData)
      .then((response) => {
        console.log('Success:', response.data);
        // Reset form fields
        setFormData({
          name: '',
          email: '',
          address: '',
          phoneNumber: '',
          password: '',
          confirmPassword: '',
          userType: '',
          gender: '',
          agreeTerms: false
        });
        setSuccessMessage('Registration successful! Please proceed to login.');
        setTimeout(() => {
          setSuccessMessage('');
          navigate('/login');
        }, 3000);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-bodyTheme">
      <div className="bg-gray-300 p-8 rounded shadow-md w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Register</h2>
        {successMessage && (
          <div className="bg-green-200 text-green-800 p-3 mb-4 rounded">
            {successMessage}
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="name" className="block font-bold mb-1">Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded px-3 py-2"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block font-bold mb-1">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded px-3 py-2"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="address" className="block font-bold mb-1">Address:</label>
            <input
              type="text"
              id="address"
              name="address"
              value={formData.address}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded px-3 py-2"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="phoneNumber" className="block font-bold mb-1">Phone Number:</label>
            <input
              type="text"
              id="phoneNumber"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded px-3 py-2"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="password" className="block font-bold mb-1">Password:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded px-3 py-2"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="confirmPassword" className="block font-bold mb-1">Confirm Password:</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded px-3 py-2"
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="userType" className="block font-bold mb-1">User Type:</label>
            <select
              id="userType"
              name="userType"
              value={formData.userType}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded px-3 py-2"
              required
            >
              <option value="">Select User Type</option>
              <option value="bmc">BMC</option>
              <option value="staff">Staff</option>
              <option value="commuter">Commuter</option>
            </select>
          </div>
          <div className="mb-4">
            <label htmlFor="gender" className="block font-bold mb-1">Gender:</label>
            <select
              id="gender"
              name="gender"
              value={formData.gender}
              onChange={handleInputChange}
              className="w-full border border-gray-300 rounded px-3 py-2"
              required
            >
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="mb-6">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="agreeTerms"
                name="agreeTerms"
                checked={formData.agreeTerms}
                onChange={handleInputChange}
                className="mr-2"
              />
              <label htmlFor="agreeTerms" className="text-sm">
                By registering, you agree to the terms &amp; conditions
              </label>
            </div>
          </div>
          <div className="flex justify-center">
            <button
              type="submit"
              className="bg-orange-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors duration-300"
            >
              Register
            </button>
          </div>
        </form>
        <div className="text-center mt-4">
          <Link to="/login" className="text-blue-600 underline">Already have an account? Login here.</Link>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;






















// import React from "react";
// import { Formik, Form, Field } from "formik";
// import { Link } from "react-router-dom";

// const RegisterPage = () => {
//   return (
//     <div className="h-auto flex items-center justify-center pt-6 mb-6">
//       <div className="h-auto bg-gray-500 py-4 px-20 rounded">
//         <Formik
//           initialValues={{
//             name: "",
//             email: "",
//             address: "",
//             user: "",
//             phone: "",
//             password: "",
//             confirmPassword: "",
//           }}
//           onSubmit={(values) => {
//             console.log(values);
//           }}
//         >
//           <Form className=" flex flex-col gap-5 ">
//             <div className="text-white">
//               <p>Are you here for the first time?</p>
//               <p>Register here!</p>
//             </div>
//             <Field
//               className="rounded px-2 py-3 h-6 text-[12px] outline-none"
//               name="name"
//               type="text"
//               placeholder="Name"
//             />
//             <Field
//               className="rounded px-2 py-3 h-6 text-[12px] outline-none"
//               name="email"
//               type="Email"
//               placeholder="Email"
//             />
//             <Field
//               className="rounded px-2 py-3 h-6 text-[12px] outline-none"
//               name="address"
//               type="text"
//               placeholder="Address"
//             />
//             <Field
//               className="rounded outline-none text-[12px]"
//               as="select"
//               name="user"
//             >
//               <option value="BusOwner">BusOwner</option>
//               <option value="Staff">Staff</option>
//               <option value="Commuter">Commuter</option>
//             </Field>
//             <Field
//               className="rounded px-2 py-3 h-6 text-[12px] outline-none"
//               name="phone"
//               type="number"
//               placeholder="Phone number"
//             />
//             <Field
//               className="rounded px-2 py-3 h-6 text-[12px] outline-none"
//               name="password"
//               type="password"
//               placeholder="Confirm Password"
//             />
//             <Field
//               className="rounded px-2 py-3 h-6 text-[12px] outline-none"
//               name="confirmPassword"
//               type="password"
//               placeholder="Password"
//             />
//             <div className="flex  gap-2 justify-start items-start">
//               <Field className="mt-1" type="checkbox" />
//               <p className="text-[12px] text-white">
//                 By registering, you agree to the terms & <br /> conditions
//               </p>
//             </div>
//             <button
//               type="submit"
//               className=" rounded py-1 text-[12px]  bg-bodyTheme text-white"
//             >
//               Register
//             </button>
//             <p className="text-[12px] text-white">
//               Already have an account?{" "}
//               <Link className="text-blue-400 underline" to="/login">
//                 click here
//               </Link>
//             </p>
//           </Form>
//         </Formik>
//         {/* <div>
//              <button className="text-center px-[4rem] border-bodyTheme border-[2px] mt-2 text-white">
//                  sign up with google
//               </button>
//         </div> */}
//       </div>
//     </div>
//   );
// };

// export default RegisterPage;
