import React from 'react'
import { BsPersonCircle , BsFillBusFrontFill , BsFillClipboard2Fill} from 'react-icons/bs';
import {LuLayoutDashboard} from "react-icons/lu"
import {LuUsers} from "react-icons/lu"
import {AiOutlineSchedule} from "react-icons/ai"
import {FaRoute} from "react-icons/fa"
import {TbReportAnalytics} from "react-icons/tb"
import {MdPayment} from "react-icons/md"
import { Link } from 'react-router-dom';


const sideBar = () => {
  return (
    <div className='h-[92vh] w-[20%] bg-bodyTheme py-5'>
        <div className='flex  gap-3 mx-3 items-center justify-center py-2 bg-gray-500'>
        <h2><BsPersonCircle size={'35px'} color='white'/></h2>
            <div className='text-white cursor-pointer'>
                <h2>John</h2>
                <h2>john@gmail.com</h2>
                <Link to={'./view-profiles'}>View Profile</Link>
            </div>
        </div>
        <div className='text-white h-[68vh] pl-6 py-2 items-center justify-center flex-col flex mx-3 bg-gray-500 mt-6 gap-4'>
              <div className="flex gap-3  w-full cursor-pointer">
                  <h2><LuLayoutDashboard size={'30px'}/></h2>
                  <h2>Dashboard</h2>
              </div>
              <div className="flex gap-3 w-full cursor-pointer">
                  <h2><LuUsers size={'30px'}/></h2>
                  <h2>Users</h2>
              </div>
              <div className="flex gap-3 w-full cursor-pointer">
                  <h2><AiOutlineSchedule size={'30px'} /></h2>
                  <h2>Schedules</h2>
              </div>
              <div className="flex gap-3 w-full cursor-pointer">
                  <h2><FaRoute size={'30px'}/></h2>
                  <h2>Routes</h2>
              </div>
              <div className="flex gap-3 w-full cursor-pointer">
                  <h2><BsFillBusFrontFill size={'30px'}/></h2>
                  <h2>Buses</h2>
              </div>
              <div className="flex gap-3 w-full cursor-pointer">
                  <h2><TbReportAnalytics size={'30px'}/></h2>
                  <h2>Reports</h2>
              </div>
              <div className="flex gap-3 w-full cursor-pointer">
                  <h2><BsFillClipboard2Fill size={'30px'}/></h2>
                  <h2>Notice</h2>
              </div>
              <div className="flex gap-3 w-full cursor-pointer">
                  <h2><MdPayment size={'30px'}/></h2>
                  <h2>Payment</h2>
              </div>
        </div>
    </div>
  )
}

export default sideBar