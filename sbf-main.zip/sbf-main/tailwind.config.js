/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        bodyTheme: "#F19335",
        nav: "#06260B",
        lightGreen: "#DDDEBB",
        lightOrange: "#6271A3",
        blue: "#0000FF"
        
      }
    },
  },
  plugins: [],
}

